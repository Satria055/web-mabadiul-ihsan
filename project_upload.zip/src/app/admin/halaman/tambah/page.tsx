import PageMetaForm from "@/components/admin/PageMetaForm";

export default function TambahHalamanPage() {
  return (
    <div className="max-w-6xl mx-auto">
       <PageMetaForm /> {/* Tanpa data = Mode Tambah */}
    </div>
  );
}