-- AlterTable
ALTER TABLE `Achievement` ADD COLUMN `description` TEXT NULL,
    ADD COLUMN `image` VARCHAR(191) NULL;
