-- AlterTable
ALTER TABLE `Testimonial` ADD COLUMN `image` VARCHAR(191) NULL;
