-- AlterTable
ALTER TABLE `SiteConfig` ADD COLUMN `logoUrl` TEXT NULL;
