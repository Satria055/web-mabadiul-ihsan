-- AlterTable
ALTER TABLE `SiteConfig` ADD COLUMN `profileImage` TEXT NULL;
