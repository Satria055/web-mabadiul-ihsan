-- AlterTable
ALTER TABLE `EducationUnit` ADD COLUMN `category` VARCHAR(191) NOT NULL DEFAULT 'Pendidikan Formal';
