-- AlterTable
ALTER TABLE `SiteConfig` ADD COLUMN `chairmanImage` TEXT NULL;
