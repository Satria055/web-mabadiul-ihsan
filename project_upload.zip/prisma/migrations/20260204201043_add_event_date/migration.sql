-- AlterTable
ALTER TABLE `Post` ADD COLUMN `eventDate` DATETIME(3) NULL;
